<?php
	$host = "localhost";
	$user = "id17258754_root";
	$pass = "2MO<H{5W#2-aH2i[";
	
	$db = "id17258754_db_restoran	";
	$conn = mysqli_connect($host,$user,$pass,$db);
	mysqli_select_db ($conn, $db);
	
	if (!$conn) {
   		die('Maaf koneksi gagal: '. $connect->connect_error);
	}
	else{
		//echo 'Tahu';
		//echo $_SESSION['viewnya'];
	}	
?>